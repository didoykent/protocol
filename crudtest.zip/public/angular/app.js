var app = angular.module('testmodule', [])
        .constant('API_URL','http://localhost:8000/api/');
